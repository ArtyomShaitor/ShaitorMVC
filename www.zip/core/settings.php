<?php

const RELATIONS_FOLDER = "relations";
const CONTROLLERS_FOLDER = "controllers";
const RESOURCES_FOLDER = "resources";